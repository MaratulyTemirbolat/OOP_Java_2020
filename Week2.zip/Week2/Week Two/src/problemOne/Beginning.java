package problemOne;

public class Beginning {

	public static void main(String[] args) {
		
	}

}
