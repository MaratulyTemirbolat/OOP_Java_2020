import java.io.Serializable;

public enum STATUS implements Serializable{
	ACCEPTED,
	DECLINED,
	QUEUE
}
