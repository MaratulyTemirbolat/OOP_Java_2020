
public interface DeletingMessage {
	public void deleteMessage(Message message);
}
