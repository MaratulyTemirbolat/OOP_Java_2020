import java.io.Serializable;

public enum FACULTY implements Serializable{
	FIT,
	MCM,
	BS,
	GF
}
