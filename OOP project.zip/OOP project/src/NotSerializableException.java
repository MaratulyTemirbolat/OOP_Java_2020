import java.io.Serializable;

/**
*/
public class NotSerializableException extends Exception implements Serializable {
	NotSerializableException(){
		super();
	}
}

