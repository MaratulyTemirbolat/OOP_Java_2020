import java.io.Serializable;

public enum POSITION implements Serializable{
	PROFESSOR,
	LECTOR,
	DEAN,
	ASSISTANT
}
