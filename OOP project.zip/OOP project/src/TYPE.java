import java.io.Serializable;

public enum TYPE implements Serializable {
	DOC,
	PDF, 
	PPT, 
	ZIP
}
