import java.io.Serializable;

/**
*/   
public class UserIdentificationException extends Exception implements Serializable{
	UserIdentificationException(){
		super();
	}
}

