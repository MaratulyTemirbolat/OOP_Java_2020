import java.lang.String[3];
/**
*/
public interface FillingAttendance {
/**
 * @param teacher 
 * @param subject 
 * @param students 
*/
public void fillAttendance(Teacher teacher, Vector<Student> students, Course subject);
}

