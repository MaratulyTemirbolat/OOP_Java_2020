import java.lang.*;
import java.lang.String[3];
/**
 * @see new value
 * @see new value
*/
public class Course {
/**
*/
private int numberOfCredits;
/**
*/
private String name;
/**
*/
private String code;
/**
*/
private Vector<CourseFile> courseFiles;
/**
*/
private Vector<Lesson>(4) lessons;
/**
*/
private Vector<Course> prerequisites;
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @return 
*/
public int getNumberOfCredits() {
    return 0;
}
/**
 * @return 
*/
public String getCode() {
    return null;
}
/**
 * @return 
*/
public String getName() {
    return null;
}
/**
 * @return 
*/
public Vector<Lesson> getLessons() {
    return null;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
}

