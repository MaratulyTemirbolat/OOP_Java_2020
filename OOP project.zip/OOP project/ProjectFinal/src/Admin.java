import java.lang.*;
import java.lang.String[3];
/**
*/
public class Admin extends Employee {
/**
*/
public void addUser() {
}
/**
 * @param user 
*/
public void removeUser(User user) {
}
/**
 * @param user 
*/
public void updateInfoUser(User user) {
}
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
}

