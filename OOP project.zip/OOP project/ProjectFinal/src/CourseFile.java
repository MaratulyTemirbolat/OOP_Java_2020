import java.lang.*;
import java.util.*;
import java.lang.String[3];
/**
*/
public class CourseFile {
/**
*/
private doubel size;
/**
*/
private String name;
/**
*/
private Date dayOfCreation;
/**
*/
private TYPE fileType;
/**
*/
public void download() {
}
/**
 * @return 
*/
public double getSize() {
    return 0;
}
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
*/
public void viewType() {
}
/**
 * @return 
*/
public Date getDayOfCreation() {
    return null;
}
/**
 * @return 
*/
public String getName() {
    return null;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
}

