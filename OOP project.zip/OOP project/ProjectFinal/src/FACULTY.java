import java.lang.String[3];
/**
*/
public class FACULTY {
/**
*/
public static FACULTY FIT;
/**
*/
public static FACULTY MCM;
/**
*/
public static FACULTY BS;
/**
*/
public static FACULTY GF;
}

