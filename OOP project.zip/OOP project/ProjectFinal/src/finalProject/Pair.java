import java.lang.*;
import java.lang.String[3];
/**
*/
public class Pair {
/**
*/
private Object partOne;
/**
*/
private Object partTwo;
/**
 * @return 
*/
public Object getPartOne() {
    return null;
}
/**
 * @return 
*/
public Object getPartTwo() {
    return null;
}
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
}

