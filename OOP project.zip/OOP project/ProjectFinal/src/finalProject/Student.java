import java.lang.*;
import java.lang.String[3];
/**
*/
public class Student extends User {
/**
*/
private int yearOfStudy;
/**
*/
private FACULTY attachedFaculty;
/**
*/
private Transcript trascript;
/**
*/
private HashMap<Course,Mark> currentCourses;
/**
*/
private String specialty;
/**
*/
private Schedule schedule;
/**
*/
public void viewTranscript() {
}
/**
 * @return 
*/
public int getYearOfStudy() {
    return 0;
}
/**
 * @return 
*/
public FACULTY getFaculty() {
    return null;
}
/**
 * @return 
*/
public Vector<Course> viewCourses() {
    return null;
}
/**
 * @param course 
 * @param day 
*/
public void viewInfoAboutTeacher(Course course, String day) {
}
/**
 * @return 
*/
public String getSpecialty() {
    return null;
}
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
/**
 * @param course 
*/
public void viewAttendance(Course course) {
}
/**
 * @param schedule 
*/
public void setSchedule(Schedule schedule) {
}
/**
*/
public void saveStudent() {
}
/**
 * @return 
*/
public Student viewStudent() {
    return null;
}
}

