import java.lang.String[3];
/**
*/
public class UserIdentificationException {
}

