import java.lang.*;
import java.util.*;
import java.lang.String[3];
/**
*/
public class Order {
/**
*/
private String description;
/**
*/
private int necessity;
/**
*/
private Date dayOfSending;
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
}

