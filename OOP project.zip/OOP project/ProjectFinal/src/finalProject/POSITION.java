import java.lang.String[3];
/**
*/
public class POSITION {
/**
*/
public static POSITION PROFESSOR;
/**
*/
public static POSITION LECTOR;
/**
*/
public static POSITION DEAN;
/**
*/
public static POSITION ASSISTANT;
}

