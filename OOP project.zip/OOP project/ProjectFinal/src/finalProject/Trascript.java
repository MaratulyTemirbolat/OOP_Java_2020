import java.lang.*;
import java.lang.String[3];
/**
*/
public class Trascript {
/**
*/
private Vector<Course> allCourses;
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param allCourses 
*/
public void setCourses(Vector<Course> allCourses) {
}
/**
 * @return 
*/
public Vector<Course> getCourses() {
    return null;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
}

