import java.lang.String[3];
/**
*/
public class TYPE {
/**
*/
public static TYPE DOC;
/**
*/
public static TYPE PDF;
/**
*/
public static TYPE PPT;
/**
*/
public static TYPE ZIP;
}

