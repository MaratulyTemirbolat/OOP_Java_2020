import java.lang.*;
import java.lang.String[3];
/**
*/
public class ORManager extends Employee implements FillingAttendance {
/**
*/
private FACULTY attachedFaculty;
/**
 * @param message 
*/
public void sendMessageToTeacher(String message) {
}
/**
 * @param newCourse 
*/
public void addCourse(Course newCourse) {
}
/**
 * @param user 
 * @return 
*/
public boolean createSubjectSchedule(User user) {
    return false;
}
/**
 * @param student 
 * @return 
*/
public String viewStudentInformatio(Student student) {
    return null;
}
/**
 * @param teacher 
 * @return 
*/
public String viewTeacherInformation(Teacher teacher) {
    return null;
}
/**
*/
public void createSubjectSchedule() {
}
/**
*/
public void operation35() {
}
/**
 * @return 
*/
public FACULTY getFaculty() {
    return null;
}
/**
 * @param teacher 
 * @param subject 
 * @param students 
*/
public void fillAttendance(Teacher teacher, Vector<Student> students, Course subject) {
}
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param o 
 * @return 
*/
public int compareTo(Object o) {
    return 0;
}
/**
 * @param manager 
*/
public void saveManager(Manager manager) {
}
/**
 * @return 
*/
public Manager viewManager() {
    return null;
}
}

