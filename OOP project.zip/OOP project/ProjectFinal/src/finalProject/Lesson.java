import java.util.*;
import java.lang.*;
import java.lang.String[3];
/**
*/
public class Lesson {
/**
*/
private Date date;
/**
*/
private int timeDuration;
/**
*/
private String typeOfLesson;
/**
 * @return 
*/
public Date getDate() {
    return null;
}
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
*/
public void getTimeDuration() {
}
/**
 * @return 
*/
public String getTypeOfLesson() {
    return null;
}
}

