import java.lang.*;
import java.lang.String[3];
/**
*/
public class Mark {
/**
*/
private double points;
/**
*/
private double gpa;
/**
*/
public void getPoints() {
}
/**
 * @return 
*/
public String toLetter() {
    return null;
}
/**
 * @return 
*/
public double getGPA() {
    return 0;
}
/**
 * @return 
*/
public String toTraditionalMark() {
    return null;
}
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
}

