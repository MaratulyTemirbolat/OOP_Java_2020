import java.lang.*;
import java.lang.String[3];
/**
*/
public class Schedule {
/**
*/
private int Map<DAY,Vector<Lesson>>;
/**
 * @return 
*/
public Map<DAY,Vector<Lesson>> getSchedule() {
    return null;
}
/**
 * @param lesson 
 * @param day 
*/
public void addSubject(DAY day, Lesson lesson) {
}
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
}

