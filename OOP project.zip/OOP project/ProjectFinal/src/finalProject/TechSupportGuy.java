import java.lang.*;
import java.lang.String[3];
/**
*/
public class TechSupportGuy extends Employee {
/**
*/
private static Vector<Order> currentOrders;
/**
 * @return 
*/
public Vector<Order> viewCurrentOrders() {
    return null;
}
/**
*/
public void acceptOrder() {
}
/**
*/
public void rejectOrder() {
}
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
/**
 * @param o 
 * @return 
*/
public int compareTo(Object o) {
    return 0;
}
/**
 * @param supportGuy 
*/
public void saveSupportGuy(TechSupportGuy supportGuy) {
}
/**
 * @return 
*/
public TechSupportGuy viewSupportGuy() {
    return null;
}
}

