import java.util.*;
import java.lang.*;
import java.lang.String[3];
/**
*/
public abstract class Employee extends User {
/**
*/
private double salary;
/**
*/
private Date hireDate;
/**
*/
private String insuranceNumber;
/**
 * @return 
*/
public String toString() {
    return null;
}
/**
 * @param o 
 * @return 
*/
public boolean equals(Object o) {
    return false;
}
/**
 * @return 
*/
public int hashCode() {
    return 0;
}
/**
 * @return 
*/
public Double getSalary() {
    return null;
}
/**
 * @param salary 
*/
public void setSalary(Double salary) {
}
/**
 * @return 
*/
public Date getHireDate() {
    return null;
}
/**
 * @return 
*/
public String getInsuranceNumber() {
    return null;
}
/**
 * @param o 
 * @return 
*/
public int compareTo(Object o) {
    return 0;
}
}

