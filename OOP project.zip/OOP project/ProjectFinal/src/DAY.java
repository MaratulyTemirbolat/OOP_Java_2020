import java.lang.String[3];
/**
*/
public class DAY {
/**
*/
public static DAY MON;
/**
*/
public static DAY TUE;
/**
*/
public static DAY WED;
/**
*/
public static DAY THU;
/**
*/
public static DAY FRI;
/**
*/
public static DAY SAT;
/**
*/
public static DAY SUN;
}

