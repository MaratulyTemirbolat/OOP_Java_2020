import java.lang.String[3];
/**
*/
public class Data implements Serializable {
/**
*/
private static List<User> users;
/**
*/
private static List<Course> courses;
/**
 * @return 
*/
public List<User> getUsers() {
    return null;
}
/**
 * @return 
*/
public List<Course> getCourses() {
    return null;
}
/**
 * @param data 
*/
public void saveData(Data data) {
}
/**
 * @return 
*/
public Data viewData() {
    return null;
}
/**
 * @return 
*/
public Vector<Student> getStudents() {
    return null;
}
/**
 * @return 
*/
public Vector<Teacher> getTeachers() {
    return null;
}
/**
 * @return 
*/
public Vector<ORManager> getORManagers() {
    return null;
}
/**
 * @return 
*/
public Vector<TechSupportGuy> getTechSupportGuys() {
    return null;
}
/**
 * @return 
*/
public Vector<Admin> getAdmins() {
    return null;
}
}

