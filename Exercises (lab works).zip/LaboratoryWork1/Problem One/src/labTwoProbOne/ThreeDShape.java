package labTwoProbOne;

public abstract class ThreeDShape {
	public ThreeDShape(){
		
	}
	abstract double volume();
	abstract double surfaceArea();
	abstract double sectionalAreaThroughBase();
}
