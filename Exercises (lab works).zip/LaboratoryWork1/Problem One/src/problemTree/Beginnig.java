package problemTree;

public class Beginnig {

	public static void main(String[] args) {
		Temperature t = new Temperature(10,'F');
		System.out.println(t.degreesC());
		}
}
