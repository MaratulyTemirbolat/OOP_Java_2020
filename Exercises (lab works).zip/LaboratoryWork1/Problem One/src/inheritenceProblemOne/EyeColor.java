package inheritenceProblemOne;

public enum EyeColor {
	BROWN,
	GREEN,
	RED
}
