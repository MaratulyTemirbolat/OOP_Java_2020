package inheritenceProblemOne;

public enum Gender {
	BOY,
	GIRL
}
