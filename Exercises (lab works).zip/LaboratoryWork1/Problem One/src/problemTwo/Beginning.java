package problemTwo;

public class Beginning {

	public static void main(String[] args) {
		Register reg = new Register("Nazerke",Subjects.MATHEMATICS);
		
	}

}
