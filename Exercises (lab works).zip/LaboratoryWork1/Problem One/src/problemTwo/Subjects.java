package problemTwo;

public enum Subjects {
	MATHEMATICS,
	PHYSICS
}
