package examples;

public interface Runnable extends Breathable,Moveable {
	public void run();
}
