package examples;

public interface Moveable {
	public void move();
}
