package examples;

public class Dog extends Animal {

	@Override
	public void breathe() {
		// TODO Auto-generated method stub
		
	}

}
