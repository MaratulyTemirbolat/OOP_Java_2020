package examples;

public interface Breathable {
	public void breathe();
}
