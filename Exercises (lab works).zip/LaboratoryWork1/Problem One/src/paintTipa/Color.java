package paintTipa;

public enum Color {
	BLACK,
	RED
}
