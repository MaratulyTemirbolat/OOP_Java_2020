package labThreeProbTwo;

public interface CanEatFood extends Moveable,CanBreathe {
	public void eatFood();
}
