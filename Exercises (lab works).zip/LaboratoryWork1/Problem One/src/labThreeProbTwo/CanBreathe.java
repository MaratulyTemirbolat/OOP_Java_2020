package labThreeProbTwo;

public interface CanBreathe {
	public void breathe();
}
