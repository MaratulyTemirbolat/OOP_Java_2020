package labThreeProbTwo;

public interface Jumpable extends Moveable {
	public void jump();
}
