package labThreeProbTwo;

public interface Flyable extends Moveable{
	public void fly();
}
