package labThreeProbTwo;

public interface Moveable {
	public void move();
}
