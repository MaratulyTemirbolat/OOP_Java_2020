package labThreeProbTwo;

public interface CanEatFish {
	public void eatFish();
}
