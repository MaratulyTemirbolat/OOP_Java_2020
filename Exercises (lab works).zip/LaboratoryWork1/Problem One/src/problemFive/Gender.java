package problemFive;

public enum Gender {
	BOY,
	GIRL
}
