package problemOne;

public class ProblemOne {

	public static void main(String[] args) {
		Analyzer stat = new Analyzer();
		stat.beginning();
	}

}
