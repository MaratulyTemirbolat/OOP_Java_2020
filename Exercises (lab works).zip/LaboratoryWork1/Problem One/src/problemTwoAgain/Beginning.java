package problemTwoAgain;

public class Beginning {

	public static void main(String[] args) {
		PencilManufactory pencilManufactor = new PencilManufactory(Colours.BLACK,50,"SUNDAY");
		pencilManufactor.addOrder(30, "MONDAY");
		
	}

}
