package problemTwoAgain;

public enum TypeOrder {
	ONLINE,
	OFFLINE
}
