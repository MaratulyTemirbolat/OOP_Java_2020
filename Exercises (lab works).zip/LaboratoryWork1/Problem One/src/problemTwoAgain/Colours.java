package problemTwoAgain;

public enum Colours {
	RED,
	BLUE,
	BLACK
}
